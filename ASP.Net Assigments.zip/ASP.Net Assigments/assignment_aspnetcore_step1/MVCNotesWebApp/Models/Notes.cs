﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;

namespace MVCNotesWebApp.Models
{
    public class Notes
    {
        public Notes()
        { }
        public Notes(int id, string text)
        {
            noteId = id;
            noteTitle = text;
        }
        [DisplayName("Note ID")]
        public int noteId { get; set; }

        [DisplayName("Note Title")]
        public string noteTitle { get; set; }

       
    }
}
