﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;

namespace MVCNotesWebApp.Models
{
    public class CompletNotes
    {
        public CompletNotes()
        { }
        public CompletNotes(int id, string text, List<NoteLabels> lbls, List<NoteCheckList> chks)
        {
            noteId = id;
            noteTitle = text;
            noteLabels = lbls;
            noteCheckLists = chks;
        }

        [DisplayName("Note ID")]
        public int noteId { get; set; }

        [DisplayName("Note Title")]
        public string noteTitle { get; set; }

        [DisplayName("Note Labels")]
        public List<NoteLabels> noteLabels { get; set; }

        [DisplayName("Note Checklists")]
        public List<NoteCheckList> noteCheckLists { get; set; }

        public int? labelID { get; set; }
    }
}
