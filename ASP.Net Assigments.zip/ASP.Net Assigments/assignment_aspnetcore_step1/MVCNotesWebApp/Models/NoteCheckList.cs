﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;

namespace MVCNotesWebApp.Models
{
    public class NoteCheckList
    {
        public NoteCheckList()
        {

        }
        public NoteCheckList(int id, string text, int nID)
        {
            CheckListID = id;
            CheckListText = text;
            NoteID = nID;
        }
        [DisplayName("CheckList ID")]
        public int CheckListID { get; set; }

        [DisplayName("CheckList Text")]
        public string CheckListText { get; set; }

        [DisplayName("Note ID")]
        public int NoteID { get; set; }
    }
}
