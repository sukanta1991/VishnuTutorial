﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;

namespace MVCNotesWebApp.Models
{
    public class NoteMapper
    {
        public NoteMapper()
        {

        }

        [DisplayName("Note ID")]
        public int noteId { get; set; }

        [DisplayName("Note Title")]
        public string noteTitle { get; set; }

        [DisplayName("Note Labels")]
        public string noteLabels { get; set; }

        [DisplayName("Note CheckLists")]
        public string noteCheckLists { get; set; }
      
    }
}
