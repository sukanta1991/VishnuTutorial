﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;

namespace MVCNotesWebApp.Models
{
    public class NoteLabels
    {
        public NoteLabels()
        {

        }
        public NoteLabels(int id,string text,int nID)
        {
            LabelID = id;
            LabelText = text;
            NoteID = nID;
        }
        [DisplayName("Label ID")]
        public int LabelID { get; set; }

        [DisplayName("Label Text")]
        public string LabelText { get; set; }

        [DisplayName("Note ID")]
        public int NoteID { get; set; }
    }
}
