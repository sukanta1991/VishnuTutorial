﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MVCNotesWebApp.Models;
using MVCNotesWebApp.ViewModel;

namespace MVCNotesWebApp.Controllers
{
    public class NotesController : Controller
    {
        //NoteViewModel obks = NoteViewModel.getInstance();
        public static List<Notes> notes = new List<Notes>();
        public static List<NoteLabels> notelabels = new List<NoteLabels>();
        public static List<NoteCheckList> notechecklists = new List<NoteCheckList>();

        public IActionResult Index()
        {
            List<CompletNotes> completNotesList = new List<CompletNotes>();
            foreach(Notes note in notes)
            {
                CompletNotes completNotes = new CompletNotes();
                completNotes.noteId = note.noteId;
                completNotes.noteTitle = note.noteTitle;
                List<NoteLabels> labellist = notelabels.FindAll(x => x.NoteID.Equals(note.noteId));
                completNotes.noteLabels = labellist;
                List<NoteCheckList> checklist = notechecklists.FindAll(x => x.NoteID.Equals(note.noteId));
                completNotes.noteCheckLists = checklist;
                completNotesList.Add(completNotes);
            }
            return View(completNotesList);
        }

        public IActionResult CreateNote()
        {
            return View();
        }

        [HttpPost]
        public IActionResult CreateNote(NoteMapper note)
        {
            int notecount = notes.Count + 1;
            if (note.noteLabels!=null)
            {
                int labelcount = notelabels.Count() + 1;
                string[] lbls = note.noteLabels.Split(';');
                foreach (string st in lbls)
                {
                    NoteLabels nlabel = new NoteLabels(labelcount, st, notecount);
                    notelabels.Add(nlabel);
                    labelcount++;
                }
            }

            if (note.noteCheckLists != null)
            {
                int checklistcount = notechecklists.Count() + 1;
                string[] chks = note.noteCheckLists.Split(';');
                foreach (string st in chks)
                {
                    NoteCheckList ncheck = new NoteCheckList(checklistcount, st, notecount);
                    notechecklists.Add(ncheck);
                    checklistcount++;
                }
            }

            Notes n = new Notes(notecount, note.noteTitle);
            notes.Add(n);
            return  RedirectToAction("Index");
        }

        public IActionResult NewLabel(int id)
        {
            ViewBag.noteid = id;
            return View();
        }

        [HttpPost]
        public IActionResult NewLabel(NoteLabels lb)
        {
            lb.LabelID= notelabels.Count + 1;
            notelabels.Add(lb);
            return RedirectToAction("Index");
        }

        public IActionResult DeleteLabel(int id)
        {
            notelabels.RemoveAll(x => x.LabelID == id);
            return RedirectToAction("Index");
        }

        public IActionResult NewCheckList(int id)
        {
            ViewBag.noteid = id;
            return View();
        }

        [HttpPost]
        public IActionResult NewCheckList(NoteCheckList chk)
        {
            chk.CheckListID = notechecklists.Count + 1;
            notechecklists.Add(chk);
            return RedirectToAction("Index");
        }

        public IActionResult DeleteCheckList(int id)
        {
            notechecklists.RemoveAll(x => x.CheckListID == id);
            return RedirectToAction("Index");
        }

        public IActionResult Details(int id)
        {
            Notes n = notes.FirstOrDefault(x => x.noteId == id);
            List<NoteLabels> lbs = notelabels.FindAll(x => x.NoteID == id);
            List<NoteCheckList> cks = notechecklists.FindAll(x => x.NoteID == id);
            CompletNotes cn = new CompletNotes(n.noteId, n.noteTitle, lbs, cks);
            return View(cn);
        }

        public IActionResult Delete(int id)
        {
            notes.RemoveAll(x => x.noteId == id);
            notelabels.RemoveAll(x => x.NoteID == id);
            notechecklists.RemoveAll(x => x.NoteID == id);
            return RedirectToAction("Index");
        }

        public IActionResult Edit(int id)
        {
            Notes n = notes.FirstOrDefault(x => x.noteId == id);
            return View(n);
        }
        [HttpPost]
        public IActionResult Edit(Notes n)
        {
            notes.Where(w => w.noteId ==n.noteId).ToList().ForEach(i => i.noteTitle = n.noteTitle);
            //Notes existing = notes.FirstOrDefault(x => x.noteId == n.noteId);
            //existing.noteTitle = n.noteTitle;
            return RedirectToAction("Index");
        }
    }
}