﻿using MVCNotesWebApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MVCNotesWebApp.ViewModel
{
    public class NoteViewModel
    {
        //public  List<NoteLabels> labels = new List<NoteLabels>();
        //public  List<NoteCheckList> checklists = new List<NoteCheckList>();
        //public  List<Notes> notes = new List<Notes>();
        //static NoteViewModel noteObj;
        //private NoteViewModel()
        //{
        //    NoteLabels lb1 = new NoteLabels(1, "label1", 1);
        //    NoteLabels lb2 = new NoteLabels(2, "label2", 1);
        //    labels.Add(lb1);
        //    labels.Add(lb2);

        //    NoteCheckList chk1 = new NoteCheckList(1, "task1", 1);
        //    NoteCheckList chk2 = new NoteCheckList(2, "task2", 1);
        //    checklists.Add(chk1);
        //    checklists.Add(chk2);

        //    Notes nt = new Notes(1, "Note1", labels, checklists);
        //    notes.Add(nt);
        //}
        //public static NoteViewModel getInstance()
        //{
        //    if(noteObj == null)
        //    {
        //        noteObj = new NoteViewModel();
        //    }
        //    return noteObj;
        //}
    }
}
