USE [master]
GO

--1. Creating necessary tables/Database for Notes application
CREATE DATABASE Assignments
GO

USE [Assignments]
--Create User Table
CREATE TABLE Users(ID INT PRIMARY KEY,
					FullName VARCHAR(50),
					Designation VARCHAR(30))

--Create Notes Table
CREATE TABLE Notes(NoteID INT IDENTITY(100,1) PRIMARY KEY,
					Title VARCHAR(50),
					UserID INT,
					FOREIGN KEY (UserID) REFERENCES Users(ID))

--Create NotesLabel Table
CREATE TABLE NotesLabel(LabelID INT IDENTITY(1,1),
							LabelText VARCHAR(50),
							NoteID INT,
							FOREIGN KEY (NoteID) REFERENCES Notes(NoteID))

--Create NotesCheckList Table
CREATE TABLE NotesCheckList(CheckID INT IDENTITY(1,1),
							Tasks VARCHAR(50),
							NoteID INT,
							FOREIGN KEY (NoteID) REFERENCES Notes(NoteID))

GO

--------------------------------------------------

--2. Adding 3 new users
	INSERT INTO Users VALUES(1234,'Vishnu N','Developer')	  --1234
	INSERT INTO Users VALUES(2345,'Sathesh K','Manager')	  --2345
	INSERT INTO Users VALUES(3456,'Sukanto S','Tester')		  --3456

GO

--3. Adding 3 notes for user 1234
	INSERT INTO Notes VALUES('Development',1234)  --100
	INSERT INTO Notes VALUES('Code Review',1234)   --101
	INSERT INTO Notes VALUES('Unit Testing',1234)  --102
	--Adding 3 note for user 2345
	INSERT INTO Notes VALUES('Timesheet',2345)     --103
	INSERT INTO Notes VALUES('Planning',2345)	  --104
	INSERT INTO Notes VALUES('Meeting',2345)	  --105
GO


--4. Adding checklists for each notes of users (1234,2345)
	INSERT INTO NotesCheckList VALUES('DevTask1',100)
	INSERT INTO NotesCheckList VALUES('DevTask2',100)
	INSERT INTO NotesCheckList VALUES('DevTask3',101)
	INSERT INTO NotesCheckList VALUES('DevTask4',101)
	INSERT INTO NotesCheckList VALUES('DevTask5',102)

	INSERT INTO NotesCheckList VALUES('ManagerTask1',103)
	INSERT INTO NotesCheckList VALUES('ManagerTask2',104)
	INSERT INTO NotesCheckList VALUES('ManagerTask3',105)

	--Adding Labels for NotesLabel tables
	INSERT INTO NotesLabel VALUES('Label1',100)
	INSERT INTO NotesLabel VALUES('Label2',100)
	INSERT INTO NotesLabel VALUES('Label3',101)
	INSERT INTO NotesLabel VALUES('Label4',101)
	INSERT INTO NotesLabel VALUES('Label5',101)
	INSERT INTO NotesLabel VALUES('Label6',102)
GO

--5. Deleting checklist item for user2 in 3rd note
	DELETE FROM NotesCheckList WHERE NoteID IN(SELECT NoteID FROM Notes WHERE NoteID=105)  --Removed "AND UserID=2345" as part of review comment -its not necessary since I have NoteId which is unique
 GO

--6. Modify the title of an existing Note
	UPDATE Notes SET Title='Development works' WHERE NoteID=100
GO

--7. Fetching all notes for all users
SELECT * FROM Users u INNER JOIN Notes n 
ON u.ID = n.UserID
GO

--8. Fetching all notes for a user
SELECT * FROM Users u INNER JOIN Notes n 
ON u.ID = n.UserID
WHERE u.FullName='Vishnu N'
GO

--9. Fetching all notes having specific label
SELECT * FROM Notes n INNER JOIN NotesLabel l 
ON n.NoteID = l.NoteID
WHERE l.LabelText='Label1'
GO

--10. Fetching all notes having specific Title
SELECT * FROM Notes WHERE Title='Meeting'
GO

--11. Fetching all notes having specific CheckList/Text
SELECT * FROM Notes n INNER JOIN NotesCheckList u
ON n.NoteID=u.NoteID
WHERE u.Tasks='DevTask3'
GO

--12. Query to display name and number of notes created by each of them
SELECT u.FullName,COUNT(n.UserId) FROM Users u INNER JOIN Notes n 
ON u.ID = n.UserID
GROUP BY u.FullName
GO
	
--13. Query to display details of user having not created a note 
SELECT * FROM Users u WHERE NOT EXISTS(SELECT * FROM Notes n WHERE n.UserID=u.ID)
GO

--14. Query to display details of user having created more than one note
SELECT n.UserID,u.FullName,u.Designation FROM Users u INNER JOIN Notes n 
ON u.ID = n.UserID
GROUP BY n.UserID,u.FullName,u.Designation
HAVING COUNT(n.UserID)>1

GO



