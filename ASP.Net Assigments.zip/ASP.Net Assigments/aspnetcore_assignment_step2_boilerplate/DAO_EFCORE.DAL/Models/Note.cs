﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace DAO_EFCORE.DAL.Models
{
    public class Note
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int NoteId { get; set; }

        public string Title { get; set; }

        public virtual ICollection<Label> Labels { get; set; }
        public virtual ICollection<Checklist> ListItems { get; set; }
    }
}
